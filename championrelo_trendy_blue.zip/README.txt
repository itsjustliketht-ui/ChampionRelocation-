Upload these files to a GitHub repository named 'championrelo' under your account itsjustliketht-ui.
Steps:
1. Create repo: https://github.com/itsjustliketht-ui/championrelo (Public)
2. Upload all files and folders (keep folder structure).
3. In repo Settings -> Pages: set Branch = main, Folder = / (root). Save.
4. Add DNS A records at your domain registrar (four GitHub IPs) and CNAME for www pointing to itsjustliketht-ui.github.io
5. In Google Search Console add domain property and verify with TXT.
6. Submit sitemap: https://championrelo.com/sitemap.xml
